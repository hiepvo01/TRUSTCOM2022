# Reviewer 1

## Comment 1

In Section III-A, the Android emulator clicks a random widget on the main user interface. However, the random clicks may not cause the app to transform to the valid activity. How do you guarantee the effectiveness and representative of the activity after random clicks.

**Answer**: Yes, this is one of the limitation of our collection system which is planned to be studied in the future. We stated this in the discussion part. 

> Currently the system works well, but it cannot traverse all user interfaces of an application by only random clicks。

## Comment 2

In Section IV-B, the figure 5(d) shows that the SSIM values of screenshots between two malware is lower than that between one malware and one benign application shown in figure 5(e). In my understanding, it means that a malware is more likely to be similar to a benign than a malware. It may cause false negative samples. 

**Answer**: We add explanation of the results in the following, which is also the limitation already discussed.  

> SSIM values in Fig. 5(d) seem to be lower than that in Fig. 5(e) because some malwares might mirror the look of benign applications to conceal its malicious behaviors

## Comment 3

This article only considers the malware with activities. However, the malware without activities cannot detected via the detection method. 
**Answer**: Exactly yes. That is the reason we discussed it and considered that the combination with other detection method might improve the performance. As described in the discussion section.

> Furthermore, not all malicious behaviors of malware payloads cannot be demonstrated by user interfaces directly. 

## Comment 4

There are a few expression errors in this article. 

We conducted a careful proof read and corrected some errors. 



# Reviewer 2

## Comment 1

However, more discussions on how this method can be used together with other methods to address its limitation could be added. 

**Answer**: this has been planned in future work, as described in the manuscript. 

>  We will also research on the combination of UI based method with other approaches.